<?php
	//in this file we define screen shot and some info about this theme
	$theme['img'] = './themes/simple/screenshot.png';
	$theme['author'] = _('Sarkesh Developers');
	$theme['name'] = _('simple');
	$theme['version'] = '0.0.3';
?>
