<?php
include("class_cstrike.php");

$server = new cstrike("88.198.35.40", 27100);

$infoarrays = $server->getInfo();

echo $infoarrays["serverinfo"]["servername"] . " has " . $infoarrays["serverinfo"]["player_cur"] . "/" . $infoarrays["serverinfo"]["player_max"] . " players!";

// Uncomment for the full data array, view source of the page to see it!
// print_r($infoarrays);
?>